/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Entite.Crypt;
import Entite.User;
import Utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Interface.IUtilisateurService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Lenovo
 */
public class ServiceUser implements IUtilisateurService<User> {

    private Connection con;
    private Statement ste;

    @Override
    public boolean ajouterUser(User u) {
        try {

            String checkQuery = "SELECT COUNT(*) FROM utilisateur WHERE login = ?";
            PreparedStatement checkStatement = DataSource.getInstance().getConnection().prepareStatement(checkQuery);
            checkStatement.setString(1, u.getLogin());
            ResultSet checkResult = checkStatement.executeQuery();
            checkResult.next();
            int count = checkResult.getInt(1);
            if (count > 0) {
                // L'événement existe déjà, ne pas l'ajouter
                System.out.println("L'user existe déjà dans la base de données");
                return false;

            }

            String requete = "INSERT INTO utilisateur (user_name,pwd,email,login,number_user,address_user,role)"
                    + "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement pst = DataSource.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setString(1, u.getUser_name());
            pst.setString(2, u.getPwd());
            pst.setString(3, u.getEmail());
            pst.setString(4, u.getLogin());
            pst.setInt(5, u.getNumber_user());
            pst.setString(6, u.getAddress_user());
            pst.setString(7, u.getRole());

            pst.executeUpdate();
            System.out.println("user inserée");

        } catch (SQLException e) {
            System.err.print(e.getMessage());

        }
        return false;
    }

    @Override
    public List<User> afficherUsers() {
        List<User> UserList = new ArrayList<>();
        try {
            String requete;
            requete = "SELECT * FROM utilisateur u  ";
            Statement st = DataSource.getInstance().getConnection()
                    .createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                User u = new User();
                u.setId_user(rs.getInt("id_user"));
                u.setUser_name(rs.getString("user_name"));
                u.setPwd(rs.getString("pwd"));
                u.setEmail(rs.getString("email"));
                u.setLogin(rs.getString("login"));
                u.setNumber_user(rs.getInt("number_user"));
                u.setAddress_user(rs.getString("address_user"));
                u.setRole(rs.getString("role"));
                System.out.println("the added users : " + u.toString());

                UserList.add(u);

            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return UserList;
    }

    @Override
    public void modifierUser(User u) {
        try {
            String requete = "UPDATE utilisateur SET user_name=?,pwd=?,email=?,login=?,number_user=?,address_user=?,role=?  WHERE id_user=?";
            PreparedStatement pst = DataSource.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setString(1, u.getUser_name());
            pst.setString(2, u.getPwd());
            pst.setString(3, u.getEmail());
            pst.setString(4, u.getLogin());

            pst.setInt(5, u.getNumber_user());
            pst.setString(6, u.getAddress_user());
            pst.setString(7, u.getRole());
            pst.setInt(8, u.getId_user());

            pst.executeUpdate();
            System.out.println("utilisateur modifié");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimerUser(User u) {
        try {
            String requete = "DELETE FROM utilisateur where id_user=?";
            PreparedStatement pst = DataSource.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, u.getId_user());
            pst.executeUpdate();
            System.out.println("user supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void updatePwd(String email, String newPassword) throws SQLException {
        String req = "UPDATE utilisateur SET pwd=? where email = ?";
        PreparedStatement pst = DataSource.getInstance().getConnection()
                .prepareStatement(req);
        pst.setString(1, newPassword);
        pst.setString(2, email);

        pst.executeUpdate();
    }

    public User GetByMail(String email) throws SQLException {
        List<User> users = new ArrayList<>();
        String req = "Select * from utilisateur where email = ?";

        PreparedStatement pst = DataSource.getInstance().getConnection()
                .prepareStatement(req);
        pst.setString(1, email);
        ResultSet rs = pst.executeQuery();
        User u = new User();
        rs.next();
        if (rs.getRow() != 0) {
            u.setId_user(rs.getInt(1));
            u.setUser_name(rs.getString(2));
            u.setPwd(rs.getString(3));
            u.setEmail(email);
               u.setLogin(rs.getString(5));
            u.setNumber_user(rs.getInt(6));
            u.setAddress_user(rs.getString(7));
            u.setRole(rs.getString(8));

            return u;
        } else {
            System.out.println("Utilisateur inexistant");
            return null;
        }
    }

}
