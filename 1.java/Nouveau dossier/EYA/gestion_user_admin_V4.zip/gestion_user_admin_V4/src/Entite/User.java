/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

/**
 *
 * @author Lenovo
 */
public class User {

    private int id_user;
    private String user_name;
    private String pwd;
    private String email;
    private String login;
    private int number_user;
    private String address_user;
    private String role;

    public User() {
    }

    public User(int id_user, String user_name, String pwd, String email, String login, int number_user, String address_user, String role) {
        this.id_user = id_user;
        this.user_name = user_name;
        this.pwd = pwd;
        this.email = email;
        this.login = login;
        this.number_user = number_user;
        this.address_user = address_user;
        this.role = role;
    }

    public User(int id_user, String user_name, String pwd, String email, String login, int number_user, String address_user) {
        this.id_user = id_user;
        this.user_name = user_name;
        this.pwd = pwd;
        this.email = email;
        this.login = login;
        this.number_user = number_user;
        this.address_user = address_user;
    }

    public User(String user_name, String pwd, String email, String login, int number_user, String address_user, String role) {
        this.user_name = user_name;
        this.pwd = pwd;
        this.email = email;
        this.login = login;
        this.number_user = number_user;
        this.address_user = address_user;
        this.role = role;
    }

    public User(String user_name, String pwd, String email, String login, String address_user, String role) {
        this.user_name = user_name;
        this.pwd = pwd;
        this.email = email;
        this.login = login;
        this.address_user = address_user;
        this.role = role;
    }

    public User(String pwd, String email, String login) {
        this.pwd = pwd;
        this.email = email;
        this.login = login;
    }

    public User(String login, int id_user, String pwd, String emai) {
        this.id_user = id_user;
        this.pwd = pwd;
        this.email = email;
        this.login = login;
    }

    public User(int id_user, String pwd, String login) {
        this.id_user = id_user;
        this.pwd = pwd;
        this.login = login;
    }

    public User(String pwd, String login) {
        this.pwd = pwd;
        this.login = login;
    }

    public User(int id_user) {
        this.id_user = id_user;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
         String hashedPwd=Crypt.hash(pwd);
        this.pwd = hashedPwd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;

    }

    public int getNumber_user() {
        return number_user;
    }

    public void setNumber_user(int number_user) {
        this.number_user = number_user;
    }



    public String getAddress_user() {
        return address_user;
    }

    public void setAddress_user(String address_user) {
        this.address_user = address_user;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public String toString() {
        return "\nUser{" + "id_user=" + id_user + ", user_name=" + user_name + ", pwd=" + pwd + ", email=" + email + ", login=" + login + ", number_user=" + number_user + ", address_user=" + address_user + ", role=" + role + '}';
    }

   

}
